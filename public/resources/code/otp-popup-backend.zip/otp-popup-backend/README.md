# WhatsApp OTP Discount Popup - Backend

Node.js backend that sends a WhatsApp OTP (AiSensy) or SMS OTP (MSG91) and creates a unique, single-use Shopify discount code after verification.

## Run
    npm install
    cp .env.example .env
    npm start

Keep MOCK_MODE=true for local testing (OTP is printed in the terminal).
For production fill in the AiSensy and Shopify values in .env and deploy over HTTPS (Render, Railway, VPS).

Never commit your .env file or share your API keys.

The Shopify popup (Liquid) is not included. Need it set up on your store?
WhatsApp +91 79007 61555 | storesbyhimanshu.com
