import "dotenv/config";
import express from "express";
import cors from "cors";
import crypto from "node:crypto";
import fs from "node:fs";
import rateLimit from "express-rate-limit";

const {
  PORT = 3000,
  ALLOWED_ORIGIN,
  OTP_CHANNEL = "whatsapp", // whatsapp (AiSensy) or sms (MSG91)
  AISENSY_API_KEY,
  AISENSY_CAMPAIGN_NAME,
  MSG91_AUTH_KEY,
  MSG91_TEMPLATE_ID,
  SHOPIFY_STORE_DOMAIN, // e.g. your-store.myshopify.com
  FIXED_COUPON_CODE, // testing: show this existing coupon instead of creating a unique one
  COUPON_POOL_FILE, // e.g. ./coupons.txt - one pre-made unique code per line (no Shopify app needed)
  SHOPIFY_CLIENT_ID, // Dev Dashboard app credentials (preferred)
  SHOPIFY_CLIENT_SECRET,
  SHOPIFY_ADMIN_TOKEN, // optional static token (older custom apps)
  SHOPIFY_API_VERSION = "2025-10",
  DISCOUNT_PERCENT = "15",
  DISCOUNT_VALID_DAYS = "7",
  MOCK_MODE = "false", // true = no SMS / no Shopify calls, for local testing
} = process.env;

const MOCK = MOCK_MODE === "true";
const OTP_TTL_MS = 5 * 60 * 1000;
const RESEND_COOLDOWN_MS = 30 * 1000;
const MAX_VERIFY_ATTEMPTS = 5;
const ISSUED_FILE = new URL("./issued-codes.json", import.meta.url);

const app = express();
app.set("trust proxy", 1);
app.use(express.json({ limit: "10kb" }));
app.use(cors({ origin: ALLOWED_ORIGIN ? ALLOWED_ORIGIN.split(",") : false }));

// ---------- helpers ----------
const otpStore = new Map(); // phone -> { hash, expires, attempts, lastSent }
const hashOtp = (phone, otp) =>
  crypto.createHash("sha256").update(`${phone}:${otp}:${process.env.OTP_HASH_SECRET || AISENSY_API_KEY || MSG91_AUTH_KEY || "dev"}`).digest("hex");

const normalizePhone = (raw) => {
  const digits = String(raw || "").replace(/\D/g, "").replace(/^(91|0)(?=\d{10}$)/, "");
  return /^[6-9]\d{9}$/.test(digits) ? digits : null;
};

const loadIssued = () => {
  try {
    return JSON.parse(fs.readFileSync(ISSUED_FILE, "utf8"));
  } catch {
    return {};
  }
};
const saveIssued = (data) => fs.writeFileSync(ISSUED_FILE, JSON.stringify(data, null, 2));

async function sendWhatsApp(phone, otp) {
  const res = await fetch("https://backend.aisensy.com/campaign/t1/api/v2", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({
      apiKey: AISENSY_API_KEY,
      campaignName: AISENSY_CAMPAIGN_NAME,
      destination: `91${phone}`,
      userName: "Customer",
      source: "otp-discount-popup",
      templateParams: [otp],
      // Authentication templates with a Copy Code button need the code here too.
      buttons: [
        { type: "button", sub_type: "url", index: 0, parameters: [{ type: "text", text: otp }] },
      ],
    }),
  });
  const data = await res.text();
  if (!res.ok) {
    console.error("AiSensy error:", res.status, data);
    throw new Error("whatsapp_failed");
  }
}

async function sendSms(phone, otp) {
  if (MOCK) {
    console.log(`[MOCK] OTP for ${phone}: ${otp}`);
    return;
  }
  if (OTP_CHANNEL === "whatsapp") return sendWhatsApp(phone, otp);
  const url = new URL("https://control.msg91.com/api/v5/otp");
  if (!MSG91_AUTH_KEY) throw new Error("sms_not_configured");
  url.searchParams.set("template_id", MSG91_TEMPLATE_ID);
  url.searchParams.set("mobile", `91${phone}`);
  url.searchParams.set("otp", otp);
  url.searchParams.set("otp_expiry", "5");
  const res = await fetch(url, {
    method: "POST",
    headers: { authkey: MSG91_AUTH_KEY, "content-type": "application/json" },
    body: "{}",
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok || data.type === "error") {
    console.error("MSG91 error:", data);
    throw new Error("sms_failed");
  }
}

// Dev Dashboard apps use client credentials; the token lasts ~24h, so cache and refresh it.
// A static SHOPIFY_ADMIN_TOKEN (older admin-created custom apps) still works as a fallback.
let shopifyToken = { value: null, expires: 0 };
async function getShopifyToken() {
  if (SHOPIFY_ADMIN_TOKEN) return SHOPIFY_ADMIN_TOKEN;
  if (shopifyToken.value && Date.now() < shopifyToken.expires - 60_000) return shopifyToken.value;
  const res = await fetch(`https://${SHOPIFY_STORE_DOMAIN}/admin/oauth/access_token`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({
      client_id: SHOPIFY_CLIENT_ID,
      client_secret: SHOPIFY_CLIENT_SECRET,
      grant_type: "client_credentials",
    }),
  });
  const json = await res.json().catch(() => ({}));
  if (!res.ok || !json.access_token) {
    console.error("Shopify token error:", res.status, JSON.stringify(json));
    throw new Error("shopify_token_failed");
  }
  shopifyToken = { value: json.access_token, expires: Date.now() + (json.expires_in || 86399) * 1000 };
  return shopifyToken.value;
}

// Pre-generated unique codes (one per line), e.g. exported from Shopify bulk discount codes.
// Needs no Shopify app or API scope. Each code is handed out once.
function takeFromPool(phone) {
  const lines = fs.readFileSync(new URL(COUPON_POOL_FILE, import.meta.url), "utf8")
    .split(/\r?\n/).map((s) => s.trim()).filter(Boolean);
  const issued = loadIssued();
  const used = new Set(Object.values(issued).map((v) => v.code));
  const code = lines.find((c) => !used.has(c));
  if (!code) throw new Error("coupon_pool_empty");
  issued[phone] = { code, at: new Date().toISOString() };
  saveIssued(issued); // synchronous: no other request can take the same code
  return code;
}

async function createShopifyCode(phone) {
  if (FIXED_COUPON_CODE) return FIXED_COUPON_CODE; // test mode: no Shopify call
  if (COUPON_POOL_FILE) return takeFromPool(phone);
  const code = `WELCOME${DISCOUNT_PERCENT}-${crypto.randomBytes(3).toString("hex").toUpperCase()}`;
  if (MOCK) return code;

  const endsAt = new Date(Date.now() + Number(DISCOUNT_VALID_DAYS) * 86400000).toISOString();
  const query = `
    mutation CreateCode($input: DiscountCodeBasicInput!) {
      discountCodeBasicCreate(basicCodeDiscount: $input) {
        codeDiscountNode { id }
        userErrors { field message }
      }
    }`;
  const variables = {
    input: {
      title: `Popup ${DISCOUNT_PERCENT}% - ${phone.slice(-4)}`,
      code,
      startsAt: new Date().toISOString(),
      endsAt,
      usageLimit: 1,
      appliesOncePerCustomer: true,
      combinesWith: { orderDiscounts: false, productDiscounts: false, shippingDiscounts: true },
      customerSelection: { all: true },
      customerGets: {
        value: { percentage: Number(DISCOUNT_PERCENT) / 100 },
        items: { all: true },
      },
    },
  };
  const res = await fetch(
    `https://${SHOPIFY_STORE_DOMAIN}/admin/api/${SHOPIFY_API_VERSION}/graphql.json`,
    {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "X-Shopify-Access-Token": await getShopifyToken(),
      },
      body: JSON.stringify({ query, variables }),
    }
  );
  const json = await res.json();
  const errors = json?.data?.discountCodeBasicCreate?.userErrors;
  if (!res.ok || json.errors || (errors && errors.length)) {
    console.error("Shopify error:", JSON.stringify(json));
    throw new Error("discount_failed");
  }
  return code;
}

// ---------- rate limits ----------
const sendLimiter = rateLimit({ windowMs: 10 * 60 * 1000, limit: 10, standardHeaders: true, legacyHeaders: false });
const verifyLimiter = rateLimit({ windowMs: 10 * 60 * 1000, limit: 30, standardHeaders: true, legacyHeaders: false });

// ---------- routes ----------
app.post("/api/send-otp", sendLimiter, async (req, res) => {
  const phone = normalizePhone(req.body?.phone);
  if (!phone) return res.status(400).json({ ok: false, error: "Enter a valid 10-digit mobile number." });

  const issued = loadIssued();
  if (issued[phone] && !FIXED_COUPON_CODE) {
    return res.status(409).json({
      ok: false,
      error: "This number has already claimed the offer.",
    });
  }

  const existing = otpStore.get(phone);
  if (existing && Date.now() - existing.lastSent < RESEND_COOLDOWN_MS) {
    return res.status(429).json({ ok: false, error: "Please wait a few seconds before requesting another OTP." });
  }

  const otp = String(crypto.randomInt(100000, 1000000));
  try {
    await sendSms(phone, otp);
  } catch {
    return res.status(502).json({ ok: false, error: "Could not send OTP. Please try again." });
  }
  otpStore.set(phone, {
    hash: hashOtp(phone, otp),
    expires: Date.now() + OTP_TTL_MS,
    attempts: 0,
    lastSent: Date.now(),
  });
  res.json({ ok: true });
});

app.post("/api/verify-otp", verifyLimiter, async (req, res) => {
  const phone = normalizePhone(req.body?.phone);
  const otp = String(req.body?.otp || "").trim();
  if (!phone || !/^\d{6}$/.test(otp)) {
    return res.status(400).json({ ok: false, error: "Enter the 6-digit OTP." });
  }

  const issued = loadIssued();
  if (issued[phone] && !FIXED_COUPON_CODE) {
    return res.status(409).json({ ok: false, error: "This number has already claimed the offer." });
  }

  const entry = otpStore.get(phone);
  if (!entry || Date.now() > entry.expires) {
    otpStore.delete(phone);
    return res.status(400).json({ ok: false, error: "OTP expired. Please request a new one." });
  }
  if (entry.attempts >= MAX_VERIFY_ATTEMPTS) {
    otpStore.delete(phone);
    return res.status(429).json({ ok: false, error: "Too many wrong attempts. Request a new OTP." });
  }
  entry.attempts += 1;

  const a = Buffer.from(entry.hash);
  const b = Buffer.from(hashOtp(phone, otp));
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
    return res.status(400).json({ ok: false, error: "Incorrect OTP." });
  }
  otpStore.delete(phone);

  try {
    const code = await createShopifyCode(phone);
    if (!FIXED_COUPON_CODE && !COUPON_POOL_FILE) {
      const current = loadIssued();
      current[phone] = { code, at: new Date().toISOString() };
      saveIssued(current);
    }
    res.json({ ok: true, code, percent: Number(DISCOUNT_PERCENT), validDays: Number(DISCOUNT_VALID_DAYS) });
  } catch {
    res.status(502).json({ ok: false, error: "Could not generate your code. Please try again." });
  }
});

app.get("/health", (_req, res) => res.json({ ok: true, mock: MOCK }));

app.listen(PORT, () => console.log(`OTP discount API running on :${PORT} (mock=${MOCK})`));
